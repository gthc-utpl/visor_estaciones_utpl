
import { Station, WeatherData } from '../types';
import { MOCK_STATIONS } from '../constants';

const API_BASE_URL = 'https://seasons-upgrades-nobody-and.trycloudflare.com';

const parseDate = (dateStr: any): string => {
  if (!dateStr) return new Date().toISOString();
  let s = String(dateStr).trim();
  const d = new Date(s.includes('T') ? s : s.replace(' ', 'T'));
  return isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
};

const mapApiToWeatherData = (rawData: any): WeatherData => {
  if (!rawData) return { timestamp: new Date().toISOString() };

  const parse = (val: any): number | null => {
    if (val === null || val === undefined || val === '') return null;
    const clean = String(val).replace(',', '.').trim();
    const n = parseFloat(clean);
    return isNaN(n) ? null : n;
  };

  const ts = rawData.fecha_loja || rawData.fecha_hora || rawData.timestamp || rawData.last_update || new Date().toISOString();

  return {
    timestamp: parseDate(ts),
    temperature: parse(rawData.temp_exterior ?? rawData.temperatura ?? rawData.temp),
    humidity: parse(rawData.hum_exterior ?? rawData.humedad ?? rawData.hum),
    pressure: parse(rawData.presion_bar ?? rawData.presion ?? rawData.bar_pressure),
    windSpeed: parse(rawData.viento_velocidad ?? rawData.vel_viento ?? rawData.wind_speed),
    windDirection: parse(rawData.viento_direccion ?? rawData.dir_viento ?? rawData.wind_dir),
    rainfall: parse(rawData.lluvia_intensidad_mm ?? rawData.precipitacion ?? rawData.rain_rate),
    solarRadiation: parse(rawData.radiacion_solar ?? rawData.sol_rad ?? rawData.solar_rad),
    uvIndex: parse(rawData.indice_uv ?? rawData.uv_index ?? rawData.uv),
    pm25: parse(rawData.pm2_5 ?? rawData.pm25 ?? rawData.pm2_5_now),
    pm10: parse(rawData.pm10 ?? rawData.pm10_now),
    batteryVoltage: parse(rawData.voltaje_bateria ?? rawData.voltaje ?? rawData.battery)
  };
};

export const fetchStations = async (): Promise<Station[]> => {
  try {
    const response = await fetch(`${API_BASE_URL}/estaciones`);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const apiData = await response.json();
    const stationsRaw = Array.isArray(apiData) ? apiData : [];

    // Combinar datos de la API con nuestra lista maestra de coordenadas
    return MOCK_STATIONS.map(masterStation => {
      const apiInfo = stationsRaw.find((s: any) => (s.station_id || s.id)?.toString() === masterStation.id);
      return {
        ...masterStation,
        name: apiInfo?.nombre_estacion || masterStation.name,
        // Mantener las coordenadas maestras si la API falla o devuelve nulos
        location: {
          ...masterStation.location,
          lat: parseFloat(apiInfo?.latitud || masterStation.location.lat),
          lng: parseFloat(apiInfo?.longitud || masterStation.location.lng),
        },
        status: apiInfo ? 'online' : masterStation.status
      };
    });
  } catch (error) {
    console.error("fetchStations failed, using master list:", error);
    return MOCK_STATIONS;
  }
};

export const fetchActualClima = async (stationId: string): Promise<WeatherData> => {
  try {
    const response = await fetch(`${API_BASE_URL}/clima/actual?station_id=${stationId}`);
    if (!response.ok) throw new Error('Error fetch actual');
    const data = await response.json();
    
    // Unificación v1.3.1: Fusiona objetos de sensores (ISS, AirLink, etc.)
    if (Array.isArray(data) && data.length > 0) {
      const unified = data.reduce((acc: any, sensor: any) => ({ ...acc, ...sensor }), {});
      return mapApiToWeatherData(unified);
    }
    return mapApiToWeatherData(data);
  } catch (error) {
    console.error(`fetchActualClima error for ${stationId}:`, error);
    return { timestamp: new Date().toISOString() };
  }
};

export const fetchClimaRango = async (stationId: string, inicio: string, fin: string): Promise<WeatherData[]> => {
  try {
    if (!inicio || !fin) return [];
    const response = await fetch(`${API_BASE_URL}/clima/rango/${stationId}?inicio=${inicio}&fin=${fin}`);
    if (!response.ok) throw new Error(`HTTP error: ${response.status}`);
    const data = await response.json();
    if (!Array.isArray(data)) return [];
    
    return data
      .map(mapApiToWeatherData)
      .filter(d => d.timestamp !== null)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  } catch (error) {
    console.error("fetchClimaRango error:", error);
    return [];
  }
};
